package customers.service;

public interface ProductService {
    void addProduct(String name, Double price, String email);
}
