package customers.repository;

import customers.Product;

public interface ProductRepository {
    void save (Product product);
}
