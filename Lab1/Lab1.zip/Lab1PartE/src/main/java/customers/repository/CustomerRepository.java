package customers.repository;

import customers.Customer;

public interface CustomerRepository {
	void save(Customer customer) ;

}
